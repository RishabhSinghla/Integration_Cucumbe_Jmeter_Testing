package com.maven.util;

/**
 * @author rishabhsinghla
 */

import java.util.Comparator;

import com.maven.model.Tshirt;

public class MyTshirtSortingComparator implements Comparator<Tshirt> {

	String sortWith;

	public MyTshirtSortingComparator(String outputPreference) {
		sortWith = outputPreference;
	}

	public int compare(Tshirt t1, Tshirt t2) {
		if (sortWith.equalsIgnoreCase("rating"))
			return t2.gettShirtRating().compareTo(t1.gettShirtRating());
		if (sortWith.equalsIgnoreCase("price"))
			return t1.gettShirtPrice().compareTo(t2.gettShirtPrice());
		if (sortWith.equalsIgnoreCase("both")) {
			int c = t2.gettShirtRating().compareTo(t1.gettShirtRating());
			if (c != 0)
				return t2.gettShirtRating().compareTo(t1.gettShirtRating());
			else
				return t1.gettShirtPrice().compareTo(t2.gettShirtPrice());
		}
		return 0;
	}
}