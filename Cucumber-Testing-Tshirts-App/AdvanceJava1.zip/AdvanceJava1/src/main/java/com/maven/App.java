package com.maven;

/**
 * @author rishabhsinghla
 */

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.maven.exception.UserFriendlyException;
import com.maven.model.Tshirt;
import com.maven.util.ReadCsv;

public class App {

	private static final String CSV_DIRECTORY = "src/main/resources/csv_files";

	public static void main(String[] args) {
		try {
			App app = new App();
			File[] files = new File(CSV_DIRECTORY).listFiles();
			if (files == null || files.length == 0) {
				throw new UserFriendlyException("No CSV files found in the directory");
			}

			Scanner scanner = new Scanner(System.in);
			boolean continueSearch = true;

			while (continueSearch) {
				System.out.println("Enter a Color(Eg: Blue/Black/White):");
				String tShirtColor = scanner.next();
				System.out.println("Enter a Gender(Eg: Male/Female/Unisex):");
				char tShirtGender = scanner.next().charAt(0);
				System.out.println("Enter a Size(Eg: S/M/L):");
				String tShirtSize = scanner.next();
				System.out.println("Enter an Output Preference(rating/price/both):");
				String sortWith = scanner.next();

				Tshirt tshirt = new Tshirt(tShirtColor, tShirtGender, tShirtSize, sortWith);
				List<Tshirt> matchedTshirt = app.searchTshirts(tshirt, files);
				if (matchedTshirt.isEmpty()) {
					System.out.println("No matching T-shirts found");
				} else {
					for (Tshirt t : matchedTshirt) {
						System.out.println(t);
					}
				}

				System.out.println("Do you want to continue searching for T-shirts? (yes/no)");
				String continueChoice = scanner.next();
				continueSearch = continueChoice.equalsIgnoreCase("yes");
			}

			scanner.close();
		} catch (UserFriendlyException e) {
			System.err.println(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Tshirt> searchTshirts(Tshirt tshirt, File[] files) {
		try {
			ReadCsv readData = new ReadCsv(tshirt);
			return readData.getMatchedData(files);
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}
}
