package com.maven.exception;

/**
 * @author rishabhsinghla
 */

public class UserFriendlyException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserFriendlyException(String s) {
		super(s);
	}
}
