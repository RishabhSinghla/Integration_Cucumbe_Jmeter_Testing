package com.maven.util;

/**
 * @author rishabhsinghla
 */

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.maven.model.Tshirt;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

public class ReadCsv {
	String inputFormat = "";
	String outputFormat = "";
	String outputPreference = "";

	public ReadCsv(Tshirt tshirt) {
		inputFormat = String.format("%s,%s,%s", tshirt.gettShirtColor(), tshirt.gettShirtGender(),
				tshirt.gettShirtSize());
		outputPreference = tshirt.getSortWith();
	}

	public List<Tshirt> getMatchedData(File[] files) throws CsvValidationException, NumberFormatException, IOException {

		List<Tshirt> matchedList = new ArrayList<Tshirt>();

		String nextRecord[];

		for (File file : files) {
			CSVReader reader = new CSVReaderBuilder(new FileReader(file)).withSkipLines(1).build();
			while ((nextRecord = reader.readNext()) != null) {

				outputFormat = String.format("%s,%s,%s", nextRecord[2], nextRecord[3], nextRecord[4]);
				if (inputFormat.equalsIgnoreCase(outputFormat)) {
					Tshirt t = new Tshirt(nextRecord[0], nextRecord[1], nextRecord[2], nextRecord[3].charAt(0),
							nextRecord[4], Double.parseDouble(nextRecord[5]), Double.parseDouble(nextRecord[6]),
							nextRecord[7].charAt(0));
					matchedList.add(t);
				}
			}
		}
		Collections.sort(matchedList, new MyTshirtSortingComparator(outputPreference));

		return matchedList;
	}
}
