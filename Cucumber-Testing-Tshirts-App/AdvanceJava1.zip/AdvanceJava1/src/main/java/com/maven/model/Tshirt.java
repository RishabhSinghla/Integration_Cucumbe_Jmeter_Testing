package com.maven.model;

/**
 * @author rishabhsinghla
 */

public class Tshirt {

	private String tShirtId;
	private String tShirtName;
	private String tShirtColor;
	private Character tShirtGender;
	private String tShirtSize;
	private Double tShirtPrice;
	private Double tShirtRating;
	private Character tShirtAvailability;
	private String sortWith;

	public Tshirt(String tShirtId, String tShirtName, String tShirtColor, Character tShirtGender, String tShirtSize,
			Double tShirtPrice, Double tShirtRating, Character tShirtAvailability) {
		this.tShirtId = tShirtId;
		this.tShirtName = tShirtName;
		this.tShirtColor = tShirtColor;
		this.tShirtGender = tShirtGender;
		this.tShirtSize = tShirtSize;
		this.tShirtPrice = tShirtPrice;
		this.tShirtRating = tShirtRating;
		this.tShirtAvailability = tShirtAvailability;
	}

	public Tshirt(String tShirtColor, Character tShirtGender, String tShirtSize, String sortWith) {
		super();
		this.tShirtColor = tShirtColor;
		this.tShirtGender = tShirtGender;
		this.tShirtSize = tShirtSize;
		this.sortWith = sortWith;
	}

	public String gettShirtId() {
		return tShirtId;
	}

	public String gettShirtName() {
		return tShirtName;
	}

	public String gettShirtColor() {
		return tShirtColor;
	}

	public Character gettShirtGender() {
		return tShirtGender;
	}

	public String gettShirtSize() {
		return tShirtSize;
	}

	public Double gettShirtPrice() {
		return tShirtPrice;
	}

	public Double gettShirtRating() {
		return tShirtRating;
	}

	public Character gettShirtAvailability() {
		return tShirtAvailability;
	}

	public String getSortWith() {
		return sortWith;
	}

	public void settShirtId(String tShirtId) {
		this.tShirtId = tShirtId;
	}

	public void settShirtName(String tShirtName) {
		this.tShirtName = tShirtName;
	}

	public void settShirtColor(String tShirtColor) {
		this.tShirtColor = tShirtColor;
	}

	public void settShirtGender(Character tShirtGender) {
		this.tShirtGender = tShirtGender;
	}

	public void settShirtSize(String tShirtSize) {
		this.tShirtSize = tShirtSize;
	}

	public void settShirtPrice(Double tShirtPrice) {
		this.tShirtPrice = tShirtPrice;
	}

	public void settShirtRating(Double tShirtRating) {
		this.tShirtRating = tShirtRating;
	}

	public void settShirtAvailability(Character tShirtAvailability) {
		this.tShirtAvailability = tShirtAvailability;
	}

	public void setSortWith(String sortWith) {
		this.sortWith = sortWith;
	}

	@Override
	public String toString() {
		return "Tshirt [tShirtId=" + tShirtId + ", tShirtName=" + tShirtName + ", tShirtColor=" + tShirtColor
				+ ", tShirtGender=" + tShirtGender + ", tShirtSize=" + tShirtSize + ", tShirtPrice=" + tShirtPrice
				+ ", tShirtRating=" + tShirtRating + ", tShirtAvailability=" + tShirtAvailability + "]";
	}

}
