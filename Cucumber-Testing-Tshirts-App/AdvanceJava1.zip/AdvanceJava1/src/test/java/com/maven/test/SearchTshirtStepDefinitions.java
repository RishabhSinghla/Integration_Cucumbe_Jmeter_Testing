package com.maven.test;

/**
 * @author rishabhsinghla
 */

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.List;

import com.maven.App;
import com.maven.model.Tshirt;

import io.cucumber.java.ParameterType;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchTshirtStepDefinitions {

	@ParameterType("[MF]")
	public Character character(String value) {
		return value.charAt(0);
	}

	private App app;
	private Tshirt tshirt;
	@SuppressWarnings("unused")
	private String color;
	@SuppressWarnings("unused")
	private Character gender;
	@SuppressWarnings("unused")
	private String size;
	@SuppressWarnings("unused")
	private String preference;
	private List<Tshirt> matchedTshirts;

	@Given("CSV files are available")
	public void csvFilesAreAvailable() {
		app = new App();
	}

	@When("I search for a T-shirt with color {string}, gender {string}, size {string}, and sort preference {string}")
	public void searchForTshirt(String color, String gender, String size, String preference) {
		this.color = color;
		this.gender = gender.charAt(0);
		this.size = size;
		this.preference = preference;
		tshirt = new Tshirt(color, gender.charAt(0), size, preference);
		File[] files = new File("src/main/resources/csv_files").listFiles();
		matchedTshirts = app.searchTshirts(tshirt, files);
	}

	@Then("I should see matching T-shirts")
	public void verifyMatchingTshirts() {
		assertEquals(true, !matchedTshirts.isEmpty());
	}

	@Then("I should see no matching T-shirts")
	public void verifyNoMatchingTshirts() {
		assertEquals(true, matchedTshirts.isEmpty());
	}
}
