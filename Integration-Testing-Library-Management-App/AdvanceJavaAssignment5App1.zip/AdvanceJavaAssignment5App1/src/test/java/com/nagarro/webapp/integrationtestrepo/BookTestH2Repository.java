package com.nagarro.webapp.integrationtestrepo;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookTestH2Repository extends JpaRepository<Book, Long> {
}
