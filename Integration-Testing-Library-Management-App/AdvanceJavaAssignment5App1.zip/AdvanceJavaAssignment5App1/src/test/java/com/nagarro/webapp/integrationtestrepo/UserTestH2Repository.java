package com.nagarro.webapp.integrationtestrepo;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserTestH2Repository extends JpaRepository<User, Long> {
}
