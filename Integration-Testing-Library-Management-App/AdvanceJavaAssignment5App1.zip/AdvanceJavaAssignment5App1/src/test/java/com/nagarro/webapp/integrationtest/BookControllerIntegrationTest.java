package com.nagarro.webapp.integrationtest;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.integrationtestrepo.BookTestH2Repository;
import com.nagarro.webapp.model.Book;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BookControllerIntegrationTest {

    @LocalServerPort
    private int port;

    private String baseUrl = "http://localhost";

    private static RestTemplate restTemplate;

    @Autowired
    private BookTestH2Repository bookTestH2Repository;

    @BeforeAll
    public static void init() {
        restTemplate = new RestTemplate();
    }

    @BeforeEach
    public void setUp() {
        baseUrl = baseUrl.concat(":").concat(port + "").concat("/api/books");
    }

    @Test
    @Sql(statements = {"INSERT INTO Book (book_id, book_code, book_name, author_name, created_date) VALUES (1L, 101L, 'Book1', 'Author1', '2024-02-25');", "INSERT INTO Book (book_id, book_code, book_name, author_name, created_date) VALUES (2L, 102L, 'Book2', 'Author2', '2024-02-26');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM Book WHERE book_id IN (1L, 2L);"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testGetAllBooks() {
        ResponseEntity<Book[]> responseEntity = restTemplate.getForEntity(baseUrl, Book[].class);
        Book[] responseBooks = responseEntity.getBody();
        assertNotNull(responseBooks);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, responseBooks.length);
    }

    @Test
    public void testCreateBook() {
        Book book = new Book(103L, "New Book", "New Author", "2024-02-27");
        ResponseEntity<Book> responseEntity = restTemplate.postForEntity(baseUrl, book, Book.class);
        Book createdBook = responseEntity.getBody();
        assertNotNull(createdBook);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(createdBook.getBookId());
        assertEquals("New Book", createdBook.getBookName());
    }

    @Test
    @Sql(statements = {"INSERT INTO Book (book_id, book_code, book_name, author_name, created_date) VALUES (3L, 103L, 'Existing Book', 'Existing Author', '2024-02-28');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM Book WHERE book_id = 3L;"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testUpdateBook() {
        Book bookToUpdate = new Book(3L, 103L, "Updated Book", "Updated Author", "2024-02-29");
        restTemplate.put(baseUrl + "/{id}", bookToUpdate, bookToUpdate.getBookId());
        Book updatedBook = bookTestH2Repository.findById(bookToUpdate.getBookId()).orElse(null);
        assertNotNull(updatedBook);
        assertEquals("Updated Book", updatedBook.getBookName());
        assertEquals(bookToUpdate.getBookId(), updatedBook.getBookId());
    }

    @Test
    @Sql(statements = {"INSERT INTO Book (book_id, book_code, book_name, author_name, created_date) VALUES (4L, 104L, 'BookToDelete', 'AuthorToDelete', '2024-03-01');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    public void testDeleteBook() {
        long bookIdToDelete = 4L;
        ResponseEntity<Void> response = restTemplate.exchange(baseUrl + "/{id}", HttpMethod.DELETE, null, Void.class, bookIdToDelete);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Book deletedBook = bookTestH2Repository.findById(bookIdToDelete).orElse(null);
        assertNull(deletedBook);
    }

}
