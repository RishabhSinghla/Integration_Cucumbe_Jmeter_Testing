package com.nagarro.webapp.integrationtestrepo;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.model.Author;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorTestH2Repository extends JpaRepository<Author, Long> {
}
