package com.nagarro.webapp.integrationtest;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.integrationtestrepo.UserTestH2Repository;
import com.nagarro.webapp.model.User;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserControllerIntegrationTest {

    @LocalServerPort
    private int port;

    private String baseUrl = "http://localhost";

    private static RestTemplate restTemplate;

    @Autowired
    private UserTestH2Repository userRepository;

    @BeforeAll
    public static void init() {
        restTemplate = new RestTemplate();
    }

    @BeforeEach
    public void setUp() {
        baseUrl = baseUrl.concat(":").concat(port + "").concat("/api/users");
    }

    @Test
    @Sql(statements = {"INSERT INTO User (user_id, user_name, user_password) VALUES (1L, 'User1', 'password'), (2L, 'User2', 'password'), (3L, 'User3', 'password');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM User WHERE user_id IN (1L, 2L, 3L);"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testGetAllUsers() {
        ResponseEntity<User[]> responseEntity = restTemplate.getForEntity(baseUrl, User[].class);
        User[] responseUsers = responseEntity.getBody();
        assertNotNull(responseUsers);
        assertEquals(3, responseUsers.length);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    @Sql(statements = {"DELETE FROM User WHERE user_id = 1L;"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testCreateUser() {
        User user = new User(1, "NewUser", "password");
        ResponseEntity<User> responseEntity = restTemplate.postForEntity(baseUrl, user, User.class);
        User createdUser = responseEntity.getBody();
        assertNotNull(createdUser);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(createdUser.getId());
        assertEquals("NewUser", createdUser.getName());
    }


    @Test
    @Sql(statements = {"INSERT INTO User (user_id, user_name, user_password) VALUES (1L, 'ExistingUser', 'password');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM User WHERE user_id = 1L;"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testGetUserByName() {
        ResponseEntity<User> responseEntity = restTemplate.getForEntity(baseUrl + "/{name}", User.class, "ExistingUser");
        User user = responseEntity.getBody();
        assertNotNull(user);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("ExistingUser", user.getName());
    }

    @Test
    @Sql(statements = {"INSERT INTO User (user_id, user_name, user_password) VALUES (2L, 'User2', 'password');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM User WHERE user_id = 2L;"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testGetUserByNameAndPassword() {
        ResponseEntity<User> responseEntity = restTemplate.getForEntity(baseUrl + "/{name}/{password}", User.class, "User2", "password");
        User user = responseEntity.getBody();
        assertNotNull(user);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("User2", user.getName());
        assertEquals("password", user.getPassword());
    }

}
