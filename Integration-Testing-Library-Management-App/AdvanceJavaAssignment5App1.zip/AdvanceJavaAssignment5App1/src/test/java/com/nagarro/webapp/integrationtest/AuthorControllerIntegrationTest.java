package com.nagarro.webapp.integrationtest;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.integrationtestrepo.AuthorTestH2Repository;
import com.nagarro.webapp.model.Author;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AuthorControllerIntegrationTest {

    @LocalServerPort
    private int port;

    private String baseUrl = "http://localhost";

    private static RestTemplate restTemplate;

    @Autowired
    private AuthorTestH2Repository authorTestH2Repository;

    @BeforeAll
    public static void init() {
        restTemplate = new RestTemplate();
    }

    @BeforeEach
    public void setUp() {
        baseUrl = baseUrl.concat(":").concat(port + "").concat("/api/authors");
    }

    @Test
    @Sql(statements = {"INSERT INTO Author_Details (author_id, author_name) VALUES (2L, 'Author1'), (3L, 'Author2'), (4L, 'Author3');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM Author_Details WHERE author_id IN (2L, 3L, 4L);"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testGetAllAuthors() {
        ResponseEntity<Author[]> responseEntity = restTemplate.getForEntity(baseUrl, Author[].class);
        Author[] responseAuthors = responseEntity.getBody();
        assertNotNull(responseAuthors);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    public void testCreateAuthor() {
        Author author = new Author(1L, "New Author");
        ResponseEntity<Author> responseEntity = restTemplate.postForEntity(baseUrl, author, Author.class);
        Author createdAuthor = responseEntity.getBody();
        assertNotNull(createdAuthor);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(createdAuthor.getAuthorId());
        assertEquals("New Author", createdAuthor.getAuthorName());
    }

    @Test
    @Sql(statements = {"INSERT INTO Author_Details (author_id, author_name) VALUES (1L, 'Existing Author');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM Author_Details WHERE author_id = 1L;"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testUpdateAuthor() {
        Author authorToUpdate = new Author(1L, "Updated Author");
        restTemplate.put(baseUrl + "/{id}", authorToUpdate, authorToUpdate.getAuthorId());
        Author updatedAuthor = authorTestH2Repository.findById(authorToUpdate.getAuthorId()).orElse(null);
        assertNotNull(updatedAuthor);
        assertEquals("Updated Author", updatedAuthor.getAuthorName());
        assertEquals(authorToUpdate.getAuthorId(), updatedAuthor.getAuthorId());
    }

    @Test
    @Sql(statements = {"INSERT INTO Author_Details (author_id, author_name) VALUES (5L, 'AuthorToDelete');"}, executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
    @Sql(statements = {"DELETE FROM Author_Details WHERE author_id = 5L;"}, executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testDeleteAuthor() {
        long authorIdToDelete = 5L;
        ResponseEntity<Void> response = restTemplate.exchange(baseUrl + "/{id}", HttpMethod.DELETE, null, Void.class, authorIdToDelete);
        assertEquals(HttpStatus.OK, response.getStatusCode()); // Ensure successful deletion
        Author deletedAuthor = authorTestH2Repository.findById(authorIdToDelete).orElse(null);
        assertNull(deletedAuthor);
    }
    
}
