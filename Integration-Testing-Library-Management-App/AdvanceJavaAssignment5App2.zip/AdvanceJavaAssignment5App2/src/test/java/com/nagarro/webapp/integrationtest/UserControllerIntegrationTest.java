package com.nagarro.webapp.integrationtest;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.controller.UserController;
import com.nagarro.webapp.model.User;
import com.nagarro.webapp.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
@WebMvcTest(UserController.class)
public class UserControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    public void testShowLoginPage() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/login")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login"));
    }

    @Test
    public void testShowRegisterPage() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/register")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("register"));
    }

    @Test
    public void testRegisterUser() throws Exception {
        User user = new User();
        user.setName("username");
        user.setPassword("password");

        doNothing().when(userService).addUser(any(User.class));

        mockMvc.perform(MockMvcRequestBuilders.post("/do_register").param("name", "username").param("password", "password")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/login"));
    }

    @Test
    public void testLogout() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/logout")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/login"));
    }

    @Test
    public void testLogoutWithUserSession() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/logout").sessionAttr("user", new User())).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/login"));
    }

    @Test
    public void testLogoutWithoutUserSession() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/logout")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/login"));
    }

    @Test
    public void testRegisterUserSuccess() throws Exception {
        User user = new User();
        user.setName("username");
        user.setPassword("password");

        doNothing().when(userService).addUser(any(User.class));

        mockMvc.perform(MockMvcRequestBuilders.post("/do_register").param("name", "username").param("password", "password")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/login"));
    }
}
