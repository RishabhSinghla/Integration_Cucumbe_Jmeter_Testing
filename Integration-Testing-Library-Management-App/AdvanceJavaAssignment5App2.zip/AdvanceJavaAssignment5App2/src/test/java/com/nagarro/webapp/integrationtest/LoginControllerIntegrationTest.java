package com.nagarro.webapp.integrationtest;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.controller.LoginController;
import com.nagarro.webapp.model.User;
import com.nagarro.webapp.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
@WebMvcTest(LoginController.class)
public class LoginControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    public void testValidUser() throws Exception {
        User mockUser = new User(1, "username", "password");

        when(userService.getUserByUsernameAndPassword(anyString(), anyString())).thenReturn(mockUser);

        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "username").param("password", "password")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/bookList"));
    }

    @Test
    public void testInvalidUser() throws Exception {
        when(userService.getUserByUsernameAndPassword(anyString(), anyString())).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "invalidUsername").param("password", "invalidPassword")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login")).andExpect(MockMvcResultMatchers.model().attributeExists("message")).andExpect(MockMvcResultMatchers.model().attribute("message", "Invalid Login Credentials!!"));
    }

    @Test
    public void testUsernameTooShort() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "shor").param("password", "password")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login")).andExpect(MockMvcResultMatchers.model().attributeExists("validation_message")).andExpect(MockMvcResultMatchers.model().attribute("validation_message", "Min size should be greater than 5"));
    }

    @Test
    public void testUsernameTooLong() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "thisUsernameIsTooLongAndExceedsTheMaximumAllowedLengthOfFiftyCharacters").param("password", "password")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login")).andExpect(MockMvcResultMatchers.model().attributeExists("validation_message")).andExpect(MockMvcResultMatchers.model().attribute("validation_message", "Max size should be less than 50"));
    }

    @Test
    public void testPasswordTooShort() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "username").param("password", "shor")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login")).andExpect(MockMvcResultMatchers.model().attributeExists("validation_message")).andExpect(MockMvcResultMatchers.model().attribute("validation_message", "Min size should be greater than 5"));
    }

    @Test
    public void testPasswordTooLong() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "username").param("password", "thisPasswordIsTooLongAndExceedsTheMaximumAllowedLengthOfFiftyCharacters")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login")).andExpect(MockMvcResultMatchers.model().attributeExists("validation_message")).andExpect(MockMvcResultMatchers.model().attribute("validation_message", "Max size should be less than 50"));
    }

    @Test
    public void testUserNotLoggedIn() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/validate").param("username", "username").param("password", "password")).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("login")).andExpect(MockMvcResultMatchers.model().attributeExists("message")).andExpect(MockMvcResultMatchers.model().attribute("message", "Invalid Login Credentials!!"));
    }

}
