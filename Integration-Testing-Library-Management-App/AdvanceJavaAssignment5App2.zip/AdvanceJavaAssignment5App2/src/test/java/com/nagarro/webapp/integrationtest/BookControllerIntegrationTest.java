package com.nagarro.webapp.integrationtest;

/**
 * @author rishabhsinghla
 */

import com.nagarro.webapp.controller.BookController;
import com.nagarro.webapp.model.Author;
import com.nagarro.webapp.model.Book;
import com.nagarro.webapp.model.User;
import com.nagarro.webapp.service.AuthorService;
import com.nagarro.webapp.service.BookService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
@WebMvcTest(BookController.class)
public class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    @MockBean
    private AuthorService authorService;

    @Test
    public void testShowBookListPage() throws Exception {

        List<Book> mockBooks = new ArrayList<>();

        when(bookService.listBooks()).thenReturn(mockBooks);

        mockMvc.perform(MockMvcRequestBuilders.get("/bookList").sessionAttr("user", new User())).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("bookList")).andExpect(MockMvcResultMatchers.model().attributeExists("books")).andExpect(MockMvcResultMatchers.model().attribute("books", mockBooks));
    }

    @Test
    public void testShowAddForm() throws Exception {

        List<Author> mockAuthors = new ArrayList<>();
        when(authorService.listAuthors()).thenReturn(mockAuthors);

        mockMvc.perform(MockMvcRequestBuilders.get("/addform").sessionAttr("user", new User())).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("addBookForm")).andExpect(MockMvcResultMatchers.model().attributeExists("authors")).andExpect(MockMvcResultMatchers.model().attribute("authors", mockAuthors));
    }


    @Test
    public void testHandleForm() throws Exception {
        Book book = new Book();
        book.setBookCode(123L);
        when(bookService.getBookByBookCode(123L)).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders.post("/add").param("bookCode", "123").param("bookName", "Test Book")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/bookList"));
    }

    @Test
    public void testShowEditForm() throws Exception {
        List<Author> mockAuthors = new ArrayList<>();
        when(authorService.listAuthors()).thenReturn(mockAuthors);

        mockMvc.perform(MockMvcRequestBuilders.get("/editform").sessionAttr("user", new User())).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.view().name("editBookForm")).andExpect(MockMvcResultMatchers.model().attributeExists("authors")).andExpect(MockMvcResultMatchers.model().attribute("authors", mockAuthors));
    }

    @Test
    public void testHandleEditForm() throws Exception {
        Book book = new Book();
        book.setBookId(1L);
        when(bookService.getBookById(1L)).thenReturn(book);

        mockMvc.perform(MockMvcRequestBuilders.get("/edit/1")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/editform"));
    }

    @Test
    public void testHandleDelete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/delete/1")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/bookList"));
    }

    @Test
    public void testUpdateBook() throws Exception {
        Book book = new Book();
        book.setBookId(1L);

        mockMvc.perform(MockMvcRequestBuilders.post("/update").param("id", "1").param("bookName", "Updated Book")).andExpect(MockMvcResultMatchers.status().is3xxRedirection()).andExpect(MockMvcResultMatchers.redirectedUrl("/bookList"));
    }
}