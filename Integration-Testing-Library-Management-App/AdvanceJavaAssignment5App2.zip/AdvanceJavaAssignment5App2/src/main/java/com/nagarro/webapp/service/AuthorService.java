package com.nagarro.webapp.service;

/**
 * @author rishabhsinghla
 */

import java.util.List;

import com.nagarro.webapp.model.Author;

public interface AuthorService {

	public List<Author> listAuthors();

}
